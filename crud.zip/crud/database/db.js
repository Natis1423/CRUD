const mysql= require('mysql');
const conexion= mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'manza'
});

conexion.connect((error)=>{
    if(error){
        console.error('El error de conexicon es: '+error);
        return
    }
    console.log('conectado');
})

module.exports=conexion;